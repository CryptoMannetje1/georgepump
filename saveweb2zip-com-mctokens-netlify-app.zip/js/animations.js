// GSAP Animations
document.addEventListener('DOMContentLoaded', function() {
    // Register ScrollTrigger plugin
    gsap.registerPlugin(ScrollTrigger);
    
    // Hero Section Animations
    initHeroAnimations();
    
    // Floating Elements Animation
    initFloatingElements();
    
    // Scroll Animations
    initScrollAnimations();
    
    // Card Flip Animations
    initCardAnimations();
    
    // Timeline Animations
    initTimelineAnimations();

    // Initialize AOS
    AOS.init({
        duration: 800,
        offset: 100,
        once: true,
        easing: 'ease-out',
        disable: 'mobile' // Disable complex animations on mobile for better performance
    });

    // Add fade-in animation to roadmap cards on mobile
    if (window.innerWidth <= 768) {
        const timelineItems = document.querySelectorAll('.timeline-item');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px'
        });

        timelineItems.forEach(item => {
            item.style.opacity = '0';
            item.style.transform = 'translateY(20px)';
            item.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            observer.observe(item);
        });
    }

    // Optimize spinning logo animation on mobile
    const rotatingCoin = document.querySelector('.rotating-coin');
    if (rotatingCoin && window.innerWidth <= 768) {
        rotatingCoin.style.willChange = 'transform';
    }
});

// Hero Section Animations
function initHeroAnimations() {
    const heroTl = gsap.timeline({ defaults: { ease: 'power3.out' } });
    
    heroTl.from('.hero-title', {
        y: 100,
        opacity: 0,
        duration: 1
    })
    .from('.hero-subtitle', {
        y: 50,
        opacity: 0,
        duration: 0.8
    }, '-=0.5')
    .from('.get-mctoken-btn', {
        y: 30,
        opacity: 0,
        duration: 0.6
    }, '-=0.3')
    .from('.hero-coin', {
        scale: 0,
        rotation: -180,
        opacity: 0,
        duration: 1.2,
        ease: 'back.out(1.7)'
    }, '-=0.8');
}

// Floating Elements Animation
function initFloatingElements() {
    const floatingElements = document.querySelectorAll('.floating-item');
    
    floatingElements.forEach((element, index) => {
        gsap.to(element, {
            y: 'random(-30, 30)',
            x: 'random(-20, 20)',
            rotation: 'random(-15, 15)',
            duration: 'random(2, 4)',
            ease: 'sine.inOut',
            repeat: -1,
            yoyo: true,
            delay: index * 0.2
        });
    });
}

// Scroll Animations
function initScrollAnimations() {
    // About Cards
    gsap.utils.toArray('.info-card').forEach((card, index) => {
        gsap.from(card, {
            scrollTrigger: {
                trigger: card,
                start: 'top bottom-=100',
                toggleActions: 'play none none reverse'
            },
            y: 100,
            opacity: 0,
            duration: 0.8,
            delay: index * 0.2
        });
    });
    
    // How It Works Steps
    gsap.utils.toArray('.step').forEach((step, index) => {
        gsap.from(step, {
            scrollTrigger: {
                trigger: step,
                start: 'top bottom-=100',
                toggleActions: 'play none none reverse'
            },
            x: index % 2 === 0 ? -100 : 100,
            opacity: 0,
            duration: 0.8
        });
    });
    
    // Tokenomics Chart
    gsap.from('.tokenomics-chart', {
        scrollTrigger: {
            trigger: '.tokenomics-chart',
            start: 'top center+=100',
            toggleActions: 'play none none reverse'
        },
        scale: 0.5,
        opacity: 0,
        duration: 1,
        ease: 'back.out(1.7)'
    });
}

// Card Flip Animations
function initCardAnimations() {
    const cards = document.querySelectorAll('.info-card');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            gsap.to(card.querySelector('.card-front'), {
                rotationY: 180,
                duration: 0.6,
                ease: 'power2.inOut'
            });
            gsap.to(card.querySelector('.card-back'), {
                rotationY: 0,
                duration: 0.6,
                ease: 'power2.inOut'
            });
        });
        
        card.addEventListener('mouseleave', () => {
            gsap.to(card.querySelector('.card-front'), {
                rotationY: 0,
                duration: 0.6,
                ease: 'power2.inOut'
            });
            gsap.to(card.querySelector('.card-back'), {
                rotationY: -180,
                duration: 0.6,
                ease: 'power2.inOut'
            });
        });
    });
}

// Timeline Animations
function initTimelineAnimations() {
    const timelineItems = document.querySelectorAll('.timeline-item');
    
    timelineItems.forEach((item, index) => {
        gsap.from(item, {
            scrollTrigger: {
                trigger: item,
                start: 'top bottom-=100',
                toggleActions: 'play none none reverse'
            },
            x: index % 2 === 0 ? -100 : 100,
            opacity: 0,
            duration: 0.8,
            delay: index * 0.2
        });
    });
}

// Burger Spinner Animation
function spinBurger(element, duration = 3) {
    return gsap.to(element, {
        rotation: '+=360',
        duration: duration,
        ease: 'power2.inOut'
    });
}

// Page Transition Animation
function pageTransition() {
    const tl = gsap.timeline();
    
    tl.to('.page-transition', {
        xPercent: 0,
        duration: 0.6,
        ease: 'power2.inOut'
    })
    .to('.page-transition', {
        xPercent: 100,
        duration: 0.6,
        ease: 'power2.inOut',
        delay: 0.1
    });
    
    return tl;
}

// Reward Notification Animation
function showRewardAnimation(notification) {
    gsap.from(notification, {
        y: -50,
        opacity: 0,
        duration: 0.5,
        ease: 'back.out(1.7)'
    });
    
    gsap.to(notification, {
        y: 20,
        opacity: 0,
        duration: 0.5,
        delay: 2.5,
        ease: 'power2.in',
        onComplete: () => notification.remove()
    });
}

// Mobile Menu Animation
function toggleMobileMenu(show) {
    const menu = document.querySelector('.navbar-collapse');
    
    gsap.to(menu, {
        x: show ? 0 : '100%',
        duration: 0.3,
        ease: 'power2.inOut'
    });
}

// Scroll Progress Animation
function updateScrollProgress() {
    gsap.to('.scroll-progress', {
        width: gsap.utils.mapRange(
            0,
            document.documentElement.scrollHeight - window.innerHeight,
            0,
            100,
            window.pageYOffset
        ) + '%',
        duration: 0.1,
        ease: 'none'
    });
}

// Initialize scroll progress animation
window.addEventListener('scroll', updateScrollProgress); 