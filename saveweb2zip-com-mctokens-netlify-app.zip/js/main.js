// Initialize AOS
document.addEventListener('DOMContentLoaded', function() {
    AOS.init({
        duration: 800,
        easing: 'ease-out',
        once: true
    });

    // Initialize scroll progress bar
    initScrollProgress();
    
    // Initialize confetti effect
    initConfettiEffect();

    // Initialize modal functionality
    initInvestorModal();
});

// Initialize Investor Modal
function initInvestorModal() {
    const claimButton = document.querySelector('.claim-airdrop-btn');
    const modal = new bootstrap.Modal(document.getElementById('investorModal'));
    const form = document.getElementById('investorVerificationForm');

    // Open modal when claim button is clicked
    claimButton.addEventListener('click', () => {
        modal.show();
    });

    // Handle form submission
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const investorKey = document.getElementById('investorKey').value;
        
        // Always show verification failed message
        showNotification(
            'Verification Failed',
            'Sorry, we couldn\'t verify your key. Please make sure you\'ve entered the correct Investor Key.'
        );

        // Reset form and close modal
        form.reset();
        modal.hide();
    });
}

// Show Notification
function showNotification(title, message) {
    const container = document.getElementById('notificationContainer');
    const notification = document.createElement('div');
    notification.className = 'notification';
    
    notification.innerHTML = `
        <div class="notification-content">
            <div class="notification-title">${title}</div>
            <div class="notification-message">${message}</div>
        </div>
        <button class="notification-close">&times;</button>
    `;

    container.appendChild(notification);

    // Handle close button click
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        notification.style.animation = 'fadeOut 0.3s ease forwards';
        setTimeout(() => {
            notification.remove();
        }, 300);
    });

    // Auto-remove notification after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.animation = 'fadeOut 0.3s ease forwards';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }
    }, 5000);
}

// Scroll Progress Bar
function initScrollProgress() {
    const progressBar = document.createElement('div');
    progressBar.className = 'scroll-progress';
    document.body.appendChild(progressBar);

    window.addEventListener('scroll', () => {
        const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
        const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (winScroll / height) * 100;
        progressBar.style.width = scrolled + '%';
    });
}

// Confetti Effect
function initConfettiEffect() {
    const confettiColors = ['#DA291C', '#FFC72C', '#27251F', '#FFFFFF'];
    
    document.querySelectorAll('.get-mctoken-btn, .claim-airdrop-btn').forEach(btn => {
        btn.addEventListener('click', createConfetti);
    });
}

function createConfetti() {
    const confettiCount = 100;
    const container = document.createElement('div');
    container.style.position = 'fixed';
    container.style.top = '0';
    container.style.left = '0';
    container.style.width = '100%';
    container.style.height = '100%';
    container.style.pointerEvents = 'none';
    container.style.zIndex = '9999';
    
    document.body.appendChild(container);
    
    for (let i = 0; i < confettiCount; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'confetti-piece';
        confetti.style.left = Math.random() * 100 + 'vw';
        confetti.style.animationDuration = (Math.random() * 3 + 2) + 's';
        confetti.style.opacity = '1';
        confetti.style.transform = `rotate(${Math.random() * 360}deg)`;
        
        // Random confetti color
        confetti.style.backgroundColor = confettiColors[Math.floor(Math.random() * confettiColors.length)];
        
        container.appendChild(confetti);
        
        confetti.addEventListener('animationend', () => {
            confetti.remove();
            if (container.children.length === 0) {
                container.remove();
            }
        });
    }
}

// Smooth Scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Intersection Observer for Timeline
const observerOptions = {
    root: null,
    threshold: 0.1
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('active');
        }
    });
}, observerOptions);

document.querySelectorAll('.timeline-item').forEach(item => {
    observer.observe(item);
}); 