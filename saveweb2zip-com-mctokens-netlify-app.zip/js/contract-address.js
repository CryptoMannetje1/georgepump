document.addEventListener('DOMContentLoaded', function() {
    const copyButton = document.querySelector('.copy-address-btn');
    const contractAddress = 'YXyjq5UeDUi4NmojovXpP7bVgxLQUrVJTpe6cZQpump';

    if (copyButton) {
        copyButton.addEventListener('click', async () => {
            try {
                await navigator.clipboard.writeText(contractAddress);
                showNotification('Success', 'Contract address copied to clipboard!');
            } catch (err) {
                showNotification('Error', 'Failed to copy address. Please try again.');
            }
        });
    }
});

function showToast(message) {
    // Remove existing toast if any
    const existingToast = document.querySelector('.toast-notification');
    if (existingToast) {
        existingToast.remove();
    }

    // Create new toast
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.textContent = message;

    // Add toast to document
    document.body.appendChild(toast);

    // Remove toast after 3 seconds
    setTimeout(() => {
        toast.style.animation = 'slideIn 0.3s ease reverse';
        setTimeout(() => toast.remove(), 300);
    }, 2700);
} 